P_tz_neo <-
function(alpha, beta, lambda,time1, time2)
{
  integrand=function(time) #function under intergral in P(t,T)
  {
    mu_t_neo(alpha, beta,time)*exp(rou_neo(alpha, beta, lambda,time1, time2=time))
  }
  integral <-integrate(integrand,time1,time2)$value
  if(integral <= 0) 
  {
    error("the integral in P_tz_neo is <= 0")
    integral=1e-5
  }
  result <- 1/(1+integral)
  return (result)
}
