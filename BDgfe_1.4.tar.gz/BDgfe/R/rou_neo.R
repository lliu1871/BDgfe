rou_neo <-
function(alpha, beta, lambda,time1, time2)
{
  y<- (-lambda)*(time2-time1)-alpha*beta*(exp(-time2/beta)-exp(-time1/beta))
  return (y)
}
