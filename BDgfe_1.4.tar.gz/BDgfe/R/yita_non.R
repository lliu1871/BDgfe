yita_non <-
function(mu,lambda,time1,time2,T)
{
  result = 1 - (1-u_t_non(mu,lambda,time1,T))/(1-u_t_non(mu,lambda,time2,T))
  if(result > 1 | result < 0) print("yita_non is wrong")
  return(result)
}
