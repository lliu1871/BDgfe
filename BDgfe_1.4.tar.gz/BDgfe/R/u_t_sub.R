u_t_sub <-
function(mu,alpha, beta,gamma,lambda,time1, time2)
{
  if(time2 < time1) print("time2 must be greater than time1")
  result <- 1 - P_tz_sub(mu,alpha, beta,gamma,lambda,time1=time1, time2=time2) * exp(rou_sub(mu,alpha, beta,gamma,lambda,time1=time1, time2=time2))
  if(result > 1 | result < 0) print("u_t_sub is wrong")
  return(result)
  
}
