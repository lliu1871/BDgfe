P_tz_non <-
function(mu, lambda,time1, time2) #lambda!=mu
{
  if(mu==lambda)integral=mu*(time2-time1)
  else {integral =mu/(mu-lambda)*(exp((mu-lambda)*(time2-time1))-1)}
  if(integral <= 0) 
  {
    print(paste(mu,lambda,integral,sep="-"))
  }
  result <- 1/(1+integral)
  return (result)
}
