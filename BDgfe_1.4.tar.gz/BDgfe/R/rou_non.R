rou_non <-
function(mu, lambda,time1, time2) #time2 > time1
{
  if(time2 < time1) print("time2 must be greater than time1")
  y<- (mu-lambda)*(time2-time1)
  return (y)
}
