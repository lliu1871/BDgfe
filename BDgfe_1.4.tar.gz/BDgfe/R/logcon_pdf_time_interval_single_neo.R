logcon_pdf_time_interval_single_neo <-
function(alpha, beta, lambda, time1, x, current_time, start_ntaxa, end_ntaxa)  #for simulation
{
  
  if(end_ntaxa < start_ntaxa) print("end_ntaxa must be greater than start_ntaxa")
  
  loglike <- log(lambda)+log(P_tz_neo(alpha, beta, lambda, x,current_time))+log(end_ntaxa-start_ntaxa)+log(1-u_t_neo(alpha, beta, lambda, x,current_time))+(end_ntaxa-start_ntaxa-1)*log(u_t_neo(alpha, beta, lambda, x,current_time))-(end_ntaxa-start_ntaxa)*log(u_t_neo(alpha, beta, lambda, time1, current_time))
  return(loglike)
}
