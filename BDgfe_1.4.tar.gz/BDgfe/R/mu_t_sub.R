mu_t_sub <-
function(mu,alpha, beta,gamma,time)
{
  z = mu+beta*exp(gamma-alpha*time)/(1+exp(gamma-alpha*time))
  #print(paste(z,time,sep="-"))
  if(z<=1e-5)return(1e-5)
  else return(z)
}
