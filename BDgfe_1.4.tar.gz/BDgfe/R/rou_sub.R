rou_sub <-
function(mu,alpha, beta,gamma, lambda,time1, time2) #time2 > time1
{
  (mu-lambda)*(time2-time1) - (beta/alpha)*(log(1+exp(gamma-alpha*time2))-log(1+exp(gamma-alpha*time1)))
}
