yita_sub <-
function(mu,alpha, beta,gamma, lambda, time1, time2, T)
{
  result <- 1- (1-u_t_sub(mu,alpha, beta,gamma, lambda,time1=time1, time2=time2))/(1-(1- P_tz_sub (mu,alpha, beta,gamma, lambda,time1=time2, time2=T))*u_t_sub(mu,alpha, beta,gamma, lambda,time1=time1, time2=time2)) 
  if(result > 1 | result < 0) print("yita_sub is wrong")
  return(result)
}
