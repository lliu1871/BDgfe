mu_t_neo <-
function(alpha, beta,time)
{
  alpha*exp(-time/beta)
}
