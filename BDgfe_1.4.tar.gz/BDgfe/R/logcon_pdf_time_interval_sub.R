logcon_pdf_time_interval_sub <-
function(mu,alpha, beta,gamma,lambda, time1, x, current_time) 
{
  
  #check if x is between time1 and current_time
  x <- c(time1, x)  #adding time1 to the duplication time list
  ndup <- length(x)-1
  end_ntaxa <- ndup + 2
  x <- sort(x)
  if(x[1] < time1 | x[ndup] > current_time) print("the duplication times are not between time1 and current_time")
  
  loglike <- log(factorial(end_ntaxa-2))-(end_ntaxa-2)*log(u_t_sub(mu,alpha, beta,gamma,lambda,time1, current_time))
  for(i in 1:ndup)
  {  
    loglike <- loglike + log(lambda)+log(1-u_t_sub(mu,alpha, beta,gamma,lambda,x[i+1], current_time))+log(P_tz_sub(mu,alpha, beta,gamma,lambda,x[i+1], current_time))
  }
  return(loglike)
}
