u_t_non <-
function(mu, lambda, time1, time2)
{
  if(time2 < time1) print("time2 must be greater than time1")
  result <- 1 - P_tz_non(mu,lambda,time1=time1, time2=time2) * exp(rou_non(mu, lambda, time1=time1, time2=time2))
  if(result > 1 | result < 0) {print("u_t_non is wrong");print(lambda)}
  return(result)
  
}
