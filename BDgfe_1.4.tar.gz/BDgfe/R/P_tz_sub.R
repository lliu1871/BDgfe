P_tz_sub <-
function(mu,alpha, beta,gamma, lambda,time1, time2)
{
  integrand=function(xx) #function under intergral in P(t,T)
  {
    mu_t_sub(mu,alpha, beta,gamma, xx)*exp(rou_sub(mu,alpha, beta,gamma, lambda,time1, xx))
  }
  integral <- integrate(integrand, time1, time2)$value
  if(integral <= 0) 
  {
    error("the integral in P_tz_sub is <= 0")
    integral=1e-5
  }
  result <- 1/(1+integral)
  if(result > 1 | result < 0) print("ptz is wrong")
  return (result)
}
