yita_neo <-
function(alpha, beta, lambda, time1, time2, T)
{
  result <- 1- (1-u_t_neo(alpha, beta, lambda,time1=time1, time2=time2))/(1-(1- P_tz_neo (alpha, beta, lambda,time1=time2, time2=T))*u_t_neo(alpha, beta, lambda,time1=time1, time2=time2)) 
  if(result > 1 | result < 0) print("yita_neo is wrong")
  return(result)
}
